#ifndef KEYBOARD_H
#define KEYBOARD_H
void keyboard_handler(struct regs *r);
void kb_install();
#endif