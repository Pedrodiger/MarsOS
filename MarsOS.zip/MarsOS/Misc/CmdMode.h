
#ifndef CMDMODE_H
#define CMDMODE_H
void SetCmdMode();
void ExecCmd(int cmd, char* str);
void FindCmd();
#endif