#ifndef COLORS
#define COLORS
#define DEFAULT_COLOR 0x9f
#define BAR_COLOR 0x1E
#define DARK_COLOR 0x0F
#define ERROR_COLOR 0x74
#endif