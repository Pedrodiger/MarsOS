#ifndef CODEMODE
#define CODEMODE
void Interpret();
void EnterCodeMode();
#endif