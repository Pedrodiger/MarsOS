#ifndef SHELLFUNCTIONS_H
#define SHELLFUNCTIONS_H
void printUsedMem(const char* s);
void floppyCMD(const char* s);
void helpCMD(const char* s);
void clearCMD(const char* s);
#endif